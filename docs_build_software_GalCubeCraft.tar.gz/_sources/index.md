# GalCubeCraft

```{toctree}
:maxdepth: 2
:caption: Contents

core_functionality
visualisation
utilities
gui
```


## Project overview

This documentation uses the repository `README.md` as the main project
home page. The README is included below so the docs site and README stay
in sync.

```{include} ../../README.md
```
