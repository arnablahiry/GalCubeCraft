GUI
===

.. automodule:: GalCubeCraft.gui
    :members:
    :undoc-members:
    :show-inheritance:


Show source
-----------

Below is the source for the GUI module (kept for reference). The Sphinx
`viewcode` extension also provides cross-linked, highlighted source views.

.. literalinclude:: ../../src/GalCubeCraft/gui.py
    :language: python
    :linenos:
